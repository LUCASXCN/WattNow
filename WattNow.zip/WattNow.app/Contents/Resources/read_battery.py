#!/usr/bin/env python3
"""WhatCable 电池百分比读取脚本
通过 usbmuxd + lockdown TLS 读取所有连接 iOS 设备的电池百分比
输出 JSON: {"UDID": {"battery": 85, "charging": true, "fullyCharged": false}, ...}
"""
import socket, struct, plistlib, ssl, os, tempfile, json, sys

MUX_PATH = "/var/run/usbmuxd"
LOCKDOWN_PORT = 62078

def open_mux():
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(10)
    s.connect(MUX_PATH)
    return s

def send_mux(s, body):
    hdr = struct.pack("<IIII", len(body) + 16, 1, 8, 1)
    s.sendall(hdr + body)

def recv_mux(s):
    hdr = s.recv(16)
    if len(hdr) < 16:
        return None
    total = struct.unpack("<I", hdr[:4])[0]
    body = b""
    while len(body) < total - 16:
        chunk = s.recv(total - 16 - len(body))
        if not chunk:
            break
        body += chunk
    return body

def pd(d):
    return plistlib.dumps(d, fmt=plistlib.FMT_BINARY)

def pl(data):
    return plistlib.loads(data)

def list_devices():
    s = open_mux()
    send_mux(s, pd({"MessageType": "ListDevices", "ProgName": "WhatCable",
                     "ClientVersionString": "2.1", "kLibUSBMuxVersion": 3}))
    resp = recv_mux(s)
    s.close()
    if not resp:
        return []
    return pl(resp).get("DeviceList", [])

def read_pair_record(device_id, udid):
    s = open_mux()
    send_mux(s, pd({"MessageType": "ReadPairRecord", "DeviceID": device_id,
                     "PairRecordID": udid, "ProgName": "WhatCable",
                     "ClientVersionString": "2.1", "kLibUSBMuxVersion": 3}))
    resp = recv_mux(s)
    s.close()
    if not resp:
        return None
    data = pl(resp).get("PairRecordData")
    if not data:
        return None
    return pl(data)

def lockdown_connect(device_id):
    s = open_mux()
    port = struct.unpack(">H", struct.pack("<H", LOCKDOWN_PORT))[0]
    send_mux(s, pd({"MessageType": "Connect", "DeviceID": device_id, "PortNumber": port}))
    ack = recv_mux(s)
    if not ack or pl(ack).get("Number") != 0:
        s.close()
        return None
    return s

def lockdown_send(s, d):
    body = pd(d)
    s.sendall(struct.pack(">I", len(body)) + body)

def lockdown_recv(s):
    hdr = s.recv(4)
    if len(hdr) < 4:
        return None
    ln = struct.unpack(">I", hdr)[0]
    body = b""
    while len(body) < ln:
        chunk = s.recv(ln - len(body))
        if not chunk:
            break
        body += chunk
    return pl(body)

def lockdown_query(s, d):
    lockdown_send(s, d)
    return lockdown_recv(s)

def read_battery_for_device(device_id, udid, pair):
    """读取单台设备的电池信息"""
    cert_file = None
    key_file = None
    s = None
    try:
        # 保存证书和私钥到临时文件
        cert_file = tempfile.NamedTemporaryFile(mode="wb", suffix=".pem", delete=False)
        key_file = tempfile.NamedTemporaryFile(mode="wb", suffix=".pem", delete=False)
        cert_file.write(pair["HostCertificate"])
        cert_file.close()
        key_file.write(pair["HostPrivateKey"])
        key_file.close()

        s = lockdown_connect(device_id)
        if not s:
            return None

        lockdown_query(s, {"Request": "QueryType"})

        ss = lockdown_query(s, {"Request": "StartSession",
                                 "HostID": pair["HostID"],
                                 "SystemBUID": pair["SystemBUID"]})
        if not ss:
            return None
        session_id = ss.get("SessionID")
        if not session_id or ss.get("EnableSessionSSL") != 1:
            return None

        # TLS 升级
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.load_cert_chain(certfile=cert_file.name, keyfile=key_file.name)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE  # 跳过服务器证书验证（设备自签名）

        ssl_sock = ctx.wrap_socket(s, server_hostname="lockdown")

        # 读取电池信息
        result = lockdown_query(ssl_sock, {
            "Request": "GetValue",
            "Domain": "com.apple.mobile.battery",
            "SessionID": session_id
        })

        ssl_sock.close()

        if result and "Value" in result:
            val = result["Value"]
            return {
                "battery": val.get("BatteryCurrentCapacity"),
                "charging": val.get("BatteryIsCharging", False),
                "fullyCharged": val.get("FullyCharged", False),
                "externalConnected": val.get("ExternalConnected", False)
            }
        return None
    except Exception:
        return None
    finally:
        if s:
            try:
                s.close()
            except:
                pass
        if cert_file:
            try:
                os.unlink(cert_file.name)
            except:
                pass
        if key_file:
            try:
                os.unlink(key_file.name)
            except:
                pass

def main():
    result = {}
    try:
        devices = list_devices()
    except Exception:
        print(json.dumps({}))
        return

    seen = set()
    for dev in devices:
        device_id = dev.get("DeviceID")
        props = dev.get("Properties", {})
        udid = props.get("SerialNumber")
        if not device_id or not udid or udid in seen:
            continue
        seen.add(udid)

        try:
            pair = read_pair_record(device_id, udid)
        except Exception:
            pair = None

        if not pair:
            continue

        battery = read_battery_for_device(device_id, udid, pair)
        if battery and battery.get("battery") is not None:
            result[udid] = battery

    print(json.dumps(result))

if __name__ == "__main__":
    main()
